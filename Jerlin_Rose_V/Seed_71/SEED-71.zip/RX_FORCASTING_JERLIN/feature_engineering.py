import pandas as pd
import numpy as np

from pathlib import Path
from sklearn.preprocessing import OneHotEncoder, StandardScaler


# ============================================================
# STEP 6 — FEATURE ENGINEERING
# ============================================================

DATA_DIR = Path("processed_data")

ANALOG_STATIC_FILE = DATA_DIR / "analog_static.csv"
ANALOG_RX_FILE = DATA_DIR / "analog_rx.csv"
NEW_STATIC_FILE = DATA_DIR / "new_drug_static.csv"
NEW_RX_FILE = DATA_DIR / "new_drug_rx.csv"
TOP5_FILE = DATA_DIR / "top5_analogs.csv"

OUTPUT_FILE = DATA_DIR / "engineered_features.csv"
ANALOG_FEATURE_FILE = DATA_DIR / "analog_engineered_features.csv"


print("=" * 70)
print("STEP 6 — FEATURE ENGINEERING")
print("=" * 70)


# ============================================================
# 1. LOAD DATA
# ============================================================

print("\nLoading processed datasets...")

analog_static = pd.read_csv(ANALOG_STATIC_FILE)
analog_rx = pd.read_csv(ANALOG_RX_FILE)

new_static = pd.read_csv(NEW_STATIC_FILE)
new_rx = pd.read_csv(NEW_RX_FILE)

top5 = pd.read_csv(TOP5_FILE)

print(f"[OK] Analog static: {len(analog_static)} rows")
print(f"[OK] Analog Rx: {len(analog_rx)} rows")
print(f"[OK] New drug static: {len(new_static)} row")
print(f"[OK] New drug Rx: {len(new_rx)} rows")
print(f"[OK] Top analogs: {len(top5)}")


# ============================================================
# 2. NEW-DRUG FEATURES
# ============================================================

print("\n" + "=" * 70)
print("1. NEW-DRUG FEATURES")
print("=" * 70)


new_rx = new_rx.sort_values("week").reset_index(drop=True)

rx_values = new_rx["rx"]


# Latest Rx
latest_rx = rx_values.iloc[-1]


# Previous Rx
previous_rx = rx_values.iloc[-2]


# Growth rate
if previous_rx != 0:
    rx_growth_rate = (
        (latest_rx - previous_rx) / previous_rx
    )
else:
    rx_growth_rate = 0.0


# Cumulative Rx
cumulative_rx = rx_values.sum()


# Rolling mean
rolling_window = min(4, len(rx_values))

rolling_mean_rx = (
    rx_values
    .rolling(window=rolling_window)
    .mean()
    .iloc[-1]
)


# Early growth slope
weeks = new_rx["week"].values
rx_array = rx_values.values

early_growth_slope = np.polyfit(
    weeks,
    rx_array,
    1
)[0]


new_features = {
    "drug_id": new_static.iloc[0]["drug_id"],

    "latest_rx": latest_rx,

    "previous_rx": previous_rx,

    "rx_growth_rate": rx_growth_rate,

    "cumulative_rx": cumulative_rx,

    "rolling_mean_rx": rolling_mean_rx,

    "early_growth_slope": early_growth_slope,
}


print(f"Latest Rx          : {latest_rx:.2f}")
print(f"Previous Rx        : {previous_rx:.2f}")
print(f"Growth rate        : {rx_growth_rate:.4f}")
print(f"Cumulative Rx      : {cumulative_rx:.2f}")
print(f"Rolling mean       : {rolling_mean_rx:.2f}")
print(f"Early growth slope : {early_growth_slope:.2f}")


# ============================================================
# 3. GET TOP-5 ANALOG RX DATA
# ============================================================

print("\n" + "=" * 70)
print("2. TOP-5 ANALOG RX DATA")
print("=" * 70)


top5_ids = top5["drug_id"].tolist()

top5_rx = analog_rx[
    analog_rx["drug_id"].isin(top5_ids)
].copy()

print(
    f"[OK] Retrieved Rx curves for "
    f"{top5_rx['drug_id'].nunique()} top analogs"
)


# ============================================================
# 4. CALCULATE FEATURES FOR EACH TOP ANALOG
# ============================================================

analog_features = []

for _, analog in top5.iterrows():

    drug_id = analog["drug_id"]

    similarity = analog["similarity_score"]

    drug_rx = top5_rx[
        top5_rx["drug_id"] == drug_id
    ].sort_values("month")

    rx = drug_rx["rx"].values

    months = drug_rx["month"].values


    # Mean Rx
    analog_mean_rx = np.mean(rx)


    # Weighted Rx
    # More recent months receive greater weight.
    weights = np.arange(1, len(rx) + 1)

    analog_weighted_rx = np.average(
        rx,
        weights=weights
    )


    # Growth rate
    first_rx = rx[0]
    last_rx = rx[-1]

    if first_rx != 0:
        analog_growth_rate = (
            (last_rx - first_rx) / first_rx
        )
    else:
        analog_growth_rate = 0.0


    # Peak Rx
    peak_rx = np.max(rx)


    # Month of peak
    month_to_peak = months[
        np.argmax(rx)
    ]


    # Variability
    analog_variability = np.std(rx)


    analog_features.append(
        {
            "drug_id": drug_id,

            "similarity_score": similarity,

            "analog_mean_rx": analog_mean_rx,

            "analog_weighted_rx": analog_weighted_rx,

            "analog_growth_rate": analog_growth_rate,

            "analog_peak_rx": peak_rx,

            "analog_month_to_peak": month_to_peak,

            "analog_variability": analog_variability,
        }
    )


analog_features_df = pd.DataFrame(
    analog_features
)


# ============================================================
# 5. DISPLAY ANALOG FEATURES
# ============================================================

print("\nTop-5 analog engineered features:")

print(
    analog_features_df.to_string(
        index=False
    )
)


# ============================================================
# 6. CREATE WEIGHTED AGGREGATE ANALOG FEATURES
# ============================================================

print("\n" + "=" * 70)
print("3. AGGREGATING TOP-5 ANALOG FEATURES")
print("=" * 70)


similarities = (
    analog_features_df["similarity_score"]
    .values
)

# Shift similarities so negative similarities
# don't create negative weights.
weights = np.maximum(
    similarities,
    0
)

if weights.sum() == 0:
    weights = np.ones(len(weights))

weights = weights / weights.sum()


weighted_analog_mean_rx = np.sum(
    analog_features_df["analog_mean_rx"].values
    * weights
)

weighted_analog_growth = np.sum(
    analog_features_df["analog_growth_rate"].values
    * weights
)

weighted_analog_peak = np.sum(
    analog_features_df["analog_peak_rx"].values
    * weights
)

weighted_analog_month_peak = np.sum(
    analog_features_df["analog_month_to_peak"].values
    * weights
)

weighted_analog_variability = np.sum(
    analog_features_df["analog_variability"].values
    * weights
)


# Simple mean of similarity
top_analog_similarity = np.mean(
    similarities
)


# ============================================================
# 7. CREATE FINAL FEATURE RECORD
# ============================================================

print("\n" + "=" * 70)
print("4. FINAL FEATURE VECTOR")
print("=" * 70)


final_features = {
    "drug_id": new_features["drug_id"],

    # --------------------------------------------------------
    # New drug Rx features
    # --------------------------------------------------------

    "latest_rx":
        new_features["latest_rx"],

    "previous_rx":
        new_features["previous_rx"],

    "rx_growth_rate":
        new_features["rx_growth_rate"],

    "cumulative_rx":
        new_features["cumulative_rx"],

    "rolling_mean_rx":
        new_features["rolling_mean_rx"],

    "early_growth_slope":
        new_features["early_growth_slope"],


    # --------------------------------------------------------
    # Analog-derived features
    # --------------------------------------------------------

    "top_analog_similarity":
        top_analog_similarity,

    "analog_mean_rx":
        weighted_analog_mean_rx,

    "analog_weighted_rx":
        np.average(
            analog_features_df["analog_weighted_rx"],
            weights=weights
        ),

    "analog_growth_rate":
        weighted_analog_growth,

    "analog_peak_rx":
        weighted_analog_peak,

    "analog_month_to_peak":
        weighted_analog_month_peak,

    "analog_variability":
        weighted_analog_variability,
}


# ============================================================
# 8. ADD STATIC FEATURES
# ============================================================

static_columns = [
    "market_size",
    "competitive_density",
    "payer_restrictiveness",
    "promotional_intensity",
    "special_designation",
    "price_tier",
]


for column in static_columns:

    final_features[column] = (
        new_static.iloc[0][column]
    )


# Add categorical features

categorical_columns = [
    "mechanism_of_action",
    "route_of_administration",
    "target_specialty",
    "launch_quarter",
]


for column in categorical_columns:

    final_features[column] = (
        new_static.iloc[0][column]
    )


# ============================================================
# 9. CREATE DATAFRAME
# ============================================================

engineered_df = pd.DataFrame(
    [final_features]
)


# ============================================================
# 10. SAVE TOP-5 ANALOG FEATURES
# ============================================================

analog_features_df.to_csv(
    ANALOG_FEATURE_FILE,
    index=False
)


# ============================================================
# 11. SAVE FINAL FEATURE DATASET
# ============================================================

engineered_df.to_csv(
    OUTPUT_FILE,
    index=False
)


# ============================================================
# 12. DISPLAY FINAL FEATURES
# ============================================================

print(
    engineered_df.T.to_string(
        header=False
    )
)


# ============================================================
# 13. FINAL SUMMARY
# ============================================================

print("\n" + "=" * 70)
print("FEATURE ENGINEERING COMPLETE")
print("=" * 70)

print(
    f"Final feature count: "
    f"{len(engineered_df.columns) - 1}"
)

print(
    f"[OK] {OUTPUT_FILE}"
)

print(
    f"[OK] {ANALOG_FEATURE_FILE}"
)

print("\n" + "=" * 70)
print("STEP 6 COMPLETE")
print("=" * 70)