import json
from pathlib import Path

import pandas as pd


# ============================================================
# STEP 3 — DATA PREPROCESSING
# ============================================================

RAW_DATA_DIR = Path("data_seed71")
OUTPUT_DIR = Path("processed_data")

OUTPUT_DIR.mkdir(exist_ok=True)


# ============================================================
# 1. LOAD RAW JSON DATA
# ============================================================

def load_json(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        return json.load(file)


print("=" * 70)
print("STEP 3 — DATA PREPROCESSING")
print("=" * 70)

print("\nLoading Seed-71 data...")

analog_data = load_json(
    RAW_DATA_DIR / "analog_drugs.json"
)

new_drug_data = load_json(
    RAW_DATA_DIR / "new_drug.json"
)

scenario_data = load_json(
    RAW_DATA_DIR / "scenario_assumptions.json"
)

print("[OK] Analog drugs loaded")
print("[OK] New drug loaded")
print("[OK] Scenario data loaded")


# ============================================================
# 2. DEFINE STATIC FEATURES
# ============================================================

STATIC_FEATURES = [
    "drug_id",
    "drug_name",
    "mechanism_of_action",
    "route_of_administration",
    "target_specialty",
    "market_size",
    "competitive_density",
    "payer_restrictiveness",
    "launch_quarter",
    "promotional_intensity",
    "special_designation",
    "price_tier",
]


# ============================================================
# 3. EXTRACT ANALOG STATIC FEATURES
# ============================================================

analog_static_records = []

for drug in analog_data:

    record = {}

    for feature in STATIC_FEATURES:
        record[feature] = drug.get(feature)

    analog_static_records.append(record)


analog_static_df = pd.DataFrame(analog_static_records)


# ============================================================
# 4. FLATTEN ANALOG MONTHLY Rx DATA
# ============================================================

analog_rx_records = []

for drug in analog_data:

    drug_id = drug["drug_id"]

    for observation in drug["rx_curve"]:

        analog_rx_records.append(
            {
                "drug_id": drug_id,
                "month": observation["month"],
                "rx": observation["rx"],
            }
        )


analog_rx_df = pd.DataFrame(analog_rx_records)


# ============================================================
# 5. EXTRACT NEW DRUG STATIC FEATURES
# ============================================================

new_drug_static_record = {}

for feature in STATIC_FEATURES:
    new_drug_static_record[feature] = new_drug_data.get(feature)


new_drug_static_df = pd.DataFrame(
    [new_drug_static_record]
)


# ============================================================
# 6. FLATTEN NEW DRUG WEEKLY Rx DATA
# ============================================================

new_drug_rx_records = []

new_drug_id = new_drug_data["drug_id"]

for observation in new_drug_data["early_rx"]:

    new_drug_rx_records.append(
        {
            "drug_id": new_drug_id,
            "week": observation["week"],
            "rx": observation["rx"],
        }
    )


new_drug_rx_df = pd.DataFrame(
    new_drug_rx_records
)


# ============================================================
# 7. SCENARIO DATA
# ============================================================

scenario_df = pd.DataFrame(scenario_data)


# ============================================================
# 8. BASIC DATA CLEANING
# ============================================================

# Remove accidental duplicate rows if any exist.
analog_static_df = analog_static_df.drop_duplicates(
    subset=["drug_id"]
)

analog_rx_df = analog_rx_df.drop_duplicates(
    subset=["drug_id", "month"]
)

new_drug_static_df = new_drug_static_df.drop_duplicates(
    subset=["drug_id"]
)

new_drug_rx_df = new_drug_rx_df.drop_duplicates(
    subset=["drug_id", "week"]
)

scenario_df = scenario_df.drop_duplicates(
    subset=["scenario_id"]
)


# ============================================================
# 9. SORT TIME-SERIES DATA
# ============================================================

analog_rx_df = analog_rx_df.sort_values(
    ["drug_id", "month"]
).reset_index(drop=True)


new_drug_rx_df = new_drug_rx_df.sort_values(
    ["drug_id", "week"]
).reset_index(drop=True)


# ============================================================
# 10. BASIC TYPE CONVERSION
# ============================================================

analog_rx_df["month"] = analog_rx_df["month"].astype(int)
analog_rx_df["rx"] = analog_rx_df["rx"].astype(float)

new_drug_rx_df["week"] = new_drug_rx_df["week"].astype(int)
new_drug_rx_df["rx"] = new_drug_rx_df["rx"].astype(float)


# ============================================================
# 11. CHECK FOR NEGATIVE Rx VALUES
# ============================================================

if (analog_rx_df["rx"] < 0).any():

    raise ValueError(
        "Negative Rx values found in analog data."
    )


if (new_drug_rx_df["rx"] < 0).any():

    raise ValueError(
        "Negative Rx values found in new-drug data."
    )


# ============================================================
# 12. CHECK FOR MISSING VALUES
# ============================================================

print("\nMissing values after preprocessing:")

print(
    "\nAnalog static:"
)

print(
    analog_static_df.isna().sum()
)


print(
    "\nAnalog Rx:"
)

print(
    analog_rx_df.isna().sum()
)


print(
    "\nNew drug static:"
)

print(
    new_drug_static_df.isna().sum()
)


print(
    "\nNew drug Rx:"
)

print(
    new_drug_rx_df.isna().sum()
)


print(
    "\nScenarios:"
)

print(
    scenario_df.isna().sum()
)


# ============================================================
# 13. SAVE PROCESSED DATA
# ============================================================

analog_static_df.to_csv(
    OUTPUT_DIR / "analog_static.csv",
    index=False
)

analog_rx_df.to_csv(
    OUTPUT_DIR / "analog_rx.csv",
    index=False
)

new_drug_static_df.to_csv(
    OUTPUT_DIR / "new_drug_static.csv",
    index=False
)

new_drug_rx_df.to_csv(
    OUTPUT_DIR / "new_drug_rx.csv",
    index=False
)

scenario_df.to_csv(
    OUTPUT_DIR / "scenarios.csv",
    index=False
)


# ============================================================
# 14. PRINT DATASET SUMMARY
# ============================================================

print("\n" + "=" * 70)
print("PREPROCESSING SUMMARY")
print("=" * 70)

print(
    f"Analog static rows : {len(analog_static_df)}"
)

print(
    f"Analog Rx rows     : {len(analog_rx_df)}"
)

print(
    f"New drug static    : {len(new_drug_static_df)}"
)

print(
    f"New drug Rx rows   : {len(new_drug_rx_df)}"
)

print(
    f"Scenario rows      : {len(scenario_df)}"
)


print("\nGenerated files:")

print(
    f"[OK] {OUTPUT_DIR / 'analog_static.csv'}"
)

print(
    f"[OK] {OUTPUT_DIR / 'analog_rx.csv'}"
)

print(
    f"[OK] {OUTPUT_DIR / 'new_drug_static.csv'}"
)

print(
    f"[OK] {OUTPUT_DIR / 'new_drug_rx.csv'}"
)

print(
    f"[OK] {OUTPUT_DIR / 'scenarios.csv'}"
)


print("\n" + "=" * 70)
print("STEP 3 PREPROCESSING COMPLETE")
print("=" * 70)