import warnings

warnings.filterwarnings("ignore")

from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

from statsmodels.tsa.arima.model import ARIMA

from scipy.optimize import curve_fit


# ============================================================
# STEP 10 — SIX FORECASTING MODELS
# ============================================================

DATA_DIR = Path("processed_data")
VALIDATION_DIR = Path("validation")
OUTPUT_DIR = Path("models")

OUTPUT_DIR.mkdir(exist_ok=True)


ANALOG_STATIC_FILE = DATA_DIR / "analog_static.csv"
ANALOG_RX_FILE = DATA_DIR / "analog_rx.csv"
NEW_STATIC_FILE = DATA_DIR / "new_drug_static.csv"
NEW_RX_FILE = DATA_DIR / "new_drug_rx.csv"
TOP5_FILE = DATA_DIR / "top5_analogs.csv"

SPLITS_FILE = (
    VALIDATION_DIR /
    "rolling_origin_splits.csv"
)


print("=" * 80)
print("STEP 10 — SIX FORECASTING MODELS")
print("=" * 80)


# ============================================================
# 1. LOAD DATA
# ============================================================

print("\nLoading data...")

analog_static = pd.read_csv(
    ANALOG_STATIC_FILE
)

analog_rx = pd.read_csv(
    ANALOG_RX_FILE
)

new_static = pd.read_csv(
    NEW_STATIC_FILE
)

new_rx = pd.read_csv(
    NEW_RX_FILE
)

top5 = pd.read_csv(
    TOP5_FILE
)

splits = pd.read_csv(
    SPLITS_FILE
)

print(
    f"[OK] Historical drugs : "
    f"{analog_static['drug_id'].nunique()}"
)

print(
    f"[OK] Historical Rx rows: "
    f"{len(analog_rx)}"
)

print(
    f"[OK] Validation splits: "
    f"{len(splits)}"
)


# ============================================================
# 2. STATIC FEATURE SIMILARITY
# ============================================================

categorical_features = [
    "mechanism_of_action",
    "route_of_administration",
    "target_specialty",
    "launch_quarter",
]

numerical_features = [
    "market_size",
    "competitive_density",
    "payer_restrictiveness",
    "promotional_intensity",
    "special_designation",
    "price_tier",
]


encoder = OneHotEncoder(
    handle_unknown="ignore",
    sparse_output=False
)

scaler = StandardScaler()


combined_cat = analog_static[
    categorical_features
]

encoded_static = encoder.fit_transform(
    combined_cat
)

scaled_static = scaler.fit_transform(
    analog_static[numerical_features]
)

static_matrix = np.hstack(
    [
        encoded_static,
        scaled_static
    ]
)


def cosine_similarity_vector(
    target_vector,
    matrix
):

    numerator = (
        matrix @ target_vector
    )

    denominator = (
        np.linalg.norm(matrix, axis=1)
        *
        np.linalg.norm(target_vector)
    )

    denominator = np.where(
        denominator == 0,
        1e-12,
        denominator
    )

    return numerator / denominator


def get_analog_ids(
    target_id,
    top_k=5
):

    target_index = analog_static.index[
        analog_static["drug_id"] == target_id
    ]

    if len(target_index) == 0:

        return []

    target_index = target_index[0]

    target_vector = static_matrix[
        target_index
    ]

    similarities = cosine_similarity_vector(
        target_vector,
        static_matrix
    )

    candidates = []

    for index, score in enumerate(
        similarities
    ):

        candidate_id = (
            analog_static.iloc[index]["drug_id"]
        )

        if candidate_id == target_id:
            continue

        candidates.append(
            (
                candidate_id,
                score
            )
        )

    candidates.sort(
        key=lambda x: x[1],
        reverse=True
    )

    return candidates[:top_k]


# ============================================================
# 3. Rx CURVE HELPER
# ============================================================

def get_curve(
    drug_id,
    start_month=None,
    end_month=None
):

    data = analog_rx[
        analog_rx["drug_id"] == drug_id
    ].sort_values("month")

    if start_month is not None:

        data = data[
            data["month"] >= start_month
        ]

    if end_month is not None:

        data = data[
            data["month"] <= end_month
        ]

    return data["rx"].values.astype(float)


# ============================================================
# 4. MODEL 1 — NAIVE
# ============================================================

def naive_forecast(
    train,
    horizon
):

    last_value = float(
        train[-1]
    )

    return np.repeat(
        max(last_value, 0),
        horizon
    )


# ============================================================
# 5. MODEL 2 — ARIMA
# ============================================================

def arima_forecast(
    train,
    horizon
):

    try:

        # Small-data-friendly ARIMA.
        # We deliberately keep the model simple
        # because each training window is short.

        model = ARIMA(
            train,
            order=(1, 1, 0)
        )

        fitted = model.fit()

        forecast = fitted.forecast(
            steps=horizon
        )

        forecast = np.asarray(
            forecast,
            dtype=float
        )

        forecast = np.maximum(
            forecast,
            0
        )

        return forecast

    except Exception:

        # Robust fallback to naive
        # if ARIMA cannot fit.

        return naive_forecast(
            train,
            horizon
        )


# ============================================================
# 6. MODEL 3 — ANALOG ONLY
# ============================================================

def analog_forecast(
    target_id,
    train_end,
    horizon,
    top_k=5
):

    analogs = get_analog_ids(
        target_id,
        top_k
    )

    curves = []
    weights = []

    for analog_id, similarity in analogs:

        curve = get_curve(
            analog_id,
            1,
            train_end + horizon
        )

        if len(curve) < train_end + horizon:
            continue

        future_curve = curve[
            train_end:
            train_end + horizon
        ]

        curves.append(
            future_curve
        )

        weights.append(
            max(similarity, 0)
        )

    if len(curves) == 0:

        target_train = get_curve(
            target_id,
            1,
            train_end
        )

        return naive_forecast(
            target_train,
            horizon
        )

    curves = np.array(
        curves
    )

    weights = np.array(
        weights
    )

    if weights.sum() == 0:

        weights = np.ones(
            len(weights)
        )

    weights = (
        weights /
        weights.sum()
    )

    forecast = np.average(
        curves,
        axis=0,
        weights=weights
    )

    return np.maximum(
        forecast,
        0
    )


# ============================================================
# 7. BASS DIFFUSION MODEL
# ============================================================

def bass_curve(
    t,
    m,
    p,
    q
):

    t = np.asarray(t)

    denominator = (
        1
        +
        (q / p)
        *
        np.exp(
            -(p + q) * t
        )
    )

    cumulative = (
        m
        *
        (
            1
            -
            np.exp(
                -(p + q) * t
            )
        )
        /
        denominator
    )

    return cumulative


def bass_incremental_rx(
    t,
    m,
    p,
    q
):

    cumulative = bass_curve(
        t,
        m,
        p,
        q
    )

    previous_t = np.maximum(
        t - 1,
        0
    )

    previous = bass_curve(
        previous_t,
        m,
        p,
        q
    )

    return np.maximum(
        cumulative - previous,
        0
    )


def bass_forecast(
    train,
    horizon
):

    train = np.asarray(
        train,
        dtype=float
    )

    train = np.maximum(
        train,
        0
    )

    n = len(train)

    t = np.arange(
        1,
        n + 1,
        dtype=float
    )

    cumulative = np.cumsum(
        train
    )

    # Initial market-potential estimate.
    m0 = max(
        cumulative[-1] * 3,
        train.max() * 10,
        1
    )

    p0 = 0.03
    q0 = 0.38

    try:

        def cumulative_model(
            t,
            m,
            p,
            q
        ):

            return bass_curve(
                t,
                m,
                p,
                q
            )

        upper_m = max(
            cumulative[-1] * 100,
            cumulative[-1] + 1
        )

        params, _ = curve_fit(
            cumulative_model,
            t,
            cumulative,
            p0=[
                m0,
                p0,
                q0
            ],
            bounds=(
                [
                    max(
                        cumulative[-1],
                        1
                    ),
                    0.0001,
                    0.0001
                ],
                [
                    upper_m,
                    2.0,
                    2.0
                ]
            ),
            maxfev=50000
        )

        m, p, q = params

        future_t = np.arange(
            n + 1,
            n + horizon + 1,
            dtype=float
        )

        future_rx = bass_incremental_rx(
            future_t,
            m,
            p,
            q
        )

        future_rx = np.maximum(
            future_rx,
            0
        )

        return future_rx

    except Exception:

        return naive_forecast(
            train,
            horizon
        )


# ============================================================
# 8. MODEL 5 — ANALOG + BASS STATIC
# ============================================================

def analog_bass_static(
    target_id,
    train,
    train_end,
    horizon
):

    analog_pred = analog_forecast(
        target_id,
        train_end,
        horizon
    )

    bass_pred = bass_forecast(
        train,
        horizon
    )

    # Fixed transparent blend.
    analog_weight = 0.60
    bass_weight = 0.40

    forecast = (
        analog_weight
        *
        analog_pred
        +
        bass_weight
        *
        bass_pred
    )

    return np.maximum(
        forecast,
        0
    )


# ============================================================
# 9. MODEL 6 — ADAPTIVE ANALOG + BASS
# ============================================================

def adaptive_analog_bass(
    target_id,
    train,
    train_end,
    horizon
):

    analog_pred = analog_forecast(
        target_id,
        train_end,
        horizon
    )

    bass_pred = bass_forecast(
        train,
        horizon
    )

    # --------------------------------------------------------
    # Compare both models against the most recent
    # observed training points.
    # --------------------------------------------------------

    evaluation_window = min(
        4,
        len(train) - 1
    )

    if evaluation_window <= 0:

        analog_weight = 0.5

    else:

        recent_actual = train[
            -evaluation_window:
        ]

        # Use the analog historical pattern
        # corresponding to those months.

        analogs = get_analog_ids(
            target_id,
            top_k=5
        )

        analog_history = []

        for analog_id, similarity in analogs:

            curve = get_curve(
                analog_id,
                1,
                train_end
            )

            if len(curve) >= train_end:

                analog_history.append(
                    curve[
                        -evaluation_window:
                    ]
                )

        if len(analog_history) == 0:

            analog_weight = 0.5

        else:

            analog_history = np.array(
                analog_history
            )

            analog_recent = (
                analog_history.mean(
                    axis=0
                )
            )

            analog_error = np.mean(
                np.abs(
                    recent_actual
                    -
                    analog_recent
                )
            )

            bass_history = bass_forecast(
                train[:-evaluation_window],
                evaluation_window
            )

            bass_error = np.mean(
                np.abs(
                    recent_actual
                    -
                    bass_history
                )
            )

            # Lower error → larger weight.
            inverse_analog = (
                1 /
                (analog_error + 1e-6)
            )

            inverse_bass = (
                1 /
                (bass_error + 1e-6)
            )

            analog_weight = (
                inverse_analog /
                (
                    inverse_analog
                    +
                    inverse_bass
                )
            )

    bass_weight = (
        1 -
        analog_weight
    )

    forecast = (
        analog_weight
        *
        analog_pred
        +
        bass_weight
        *
        bass_pred
    )

    return np.maximum(
        forecast,
        0
    )


# ============================================================
# 10. METRICS
# ============================================================

def safe_mape(
    actual,
    predicted
):

    actual = np.asarray(
        actual,
        dtype=float
    )

    predicted = np.asarray(
        predicted,
        dtype=float
    )

    mask = (
        actual != 0
    )

    if mask.sum() == 0:

        return np.nan

    return np.mean(
        np.abs(
            (
                actual[mask]
                -
                predicted[mask]
            )
            /
            actual[mask]
        )
    ) * 100


def smape(
    actual,
    predicted
):

    actual = np.asarray(
        actual,
        dtype=float
    )

    predicted = np.asarray(
        predicted,
        dtype=float
    )

    denominator = (
        np.abs(actual)
        +
        np.abs(predicted)
    )

    mask = (
        denominator != 0
    )

    if mask.sum() == 0:

        return np.nan

    return np.mean(
        2
        *
        np.abs(
            predicted[mask]
            -
            actual[mask]
        )
        /
        denominator[mask]
    ) * 100


def mase(
    actual,
    predicted,
    train
):

    actual = np.asarray(
        actual,
        dtype=float
    )

    predicted = np.asarray(
        predicted,
        dtype=float
    )

    train = np.asarray(
        train,
        dtype=float
    )

    if len(train) < 2:

        return np.nan

    naive_scale = np.mean(
        np.abs(
            np.diff(train)
        )
    )

    if naive_scale == 0:

        return np.nan

    return (
        np.mean(
            np.abs(
                actual
                -
                predicted
            )
        )
        /
        naive_scale
    )


def calculate_metrics(
    actual,
    predicted,
    train
):

    mae = mean_absolute_error(
        actual,
        predicted
    )

    rmse = np.sqrt(
        mean_squared_error(
            actual,
            predicted
        )
    )

    mape = safe_mape(
        actual,
        predicted
    )

    smape_value = smape(
        actual,
        predicted
    )

    mase_value = mase(
        actual,
        predicted,
        train
    )

    try:

        r2 = r2_score(
            actual,
            predicted
        )

    except Exception:

        r2 = np.nan

    return {
        "MAE": mae,
        "RMSE": rmse,
        "MAPE": mape,
        "sMAPE": smape_value,
        "MASE": mase_value,
        "R2": r2
    }


# ============================================================
# 11. CLASSIFICATION METRICS
# ============================================================

def classification_metrics(
    actual,
    predicted,
    train
):

    # Threshold is derived ONLY from training data.
    threshold = np.median(
        train
    )

    actual_high = (
        np.asarray(actual)
        >= threshold
    )

    predicted_high = (
        np.asarray(predicted)
        >= threshold
    )

    tp = np.sum(
        actual_high &
        predicted_high
    )

    fp = np.sum(
        ~actual_high &
        predicted_high
    )

    fn = np.sum(
        actual_high &
        ~predicted_high
    )

    tn = np.sum(
        ~actual_high &
        ~predicted_high
    )

    accuracy = (
        (tp + tn)
        /
        max(
            tp + tn + fp + fn,
            1
        )
    )

    precision = (
        tp /
        max(
            tp + fp,
            1
        )
    )

    recall = (
        tp /
        max(
            tp + fn,
            1
        )
    )

    f1 = (
        2
        *
        precision
        *
        recall
        /
        max(
            precision + recall,
            1e-12
        )
    )

    return {
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "F1": f1
    }


# ============================================================
# 12. MODEL REGISTRY
# ============================================================

MODEL_NAMES = [
    "Naive",
    "ARIMA",
    "Analog-Only",
    "Bass",
    "Analog + Bass Static",
    "Analog + Bass Adaptive"
]


# ============================================================
# 13. RUN ROLLING BACKTEST
# ============================================================

print("\n" + "=" * 80)
print("ROLLING-ORIGIN BACKTEST")
print("=" * 80)


results = []
prediction_records = []


drug_ids = (
    analog_static["drug_id"]
    .tolist()
)


for split_number, split in splits.iterrows():

    split_id = split["split_id"]

    train_end = int(
        split["train_end"]
    )

    validation_start = int(
        split["validation_start"]
    )

    validation_end = int(
        split["validation_end"]
    )

    horizon = (
        validation_end
        -
        validation_start
        +
        1
    )


    print(
        f"\n{split_id}: "
        f"Train 1–{train_end} "
        f"→ "
        f"Validate "
        f"{validation_start}–{validation_end}"
    )


    for drug_id in drug_ids:

        train = get_curve(
            drug_id,
            1,
            train_end
        )

        actual = get_curve(
            drug_id,
            validation_start,
            validation_end
        )

        if (
            len(train) != train_end
            or
            len(actual) != horizon
        ):

            continue


        predictions = {}


        # ----------------------------------------------------
        # MODEL 1
        # ----------------------------------------------------

        predictions["Naive"] = (
            naive_forecast(
                train,
                horizon
            )
        )


        # ----------------------------------------------------
        # MODEL 2
        # ----------------------------------------------------

        predictions["ARIMA"] = (
            arima_forecast(
                train,
                horizon
            )
        )


        # ----------------------------------------------------
        # MODEL 3
        # ----------------------------------------------------

        predictions["Analog-Only"] = (
            analog_forecast(
                drug_id,
                train_end,
                horizon
            )
        )


        # ----------------------------------------------------
        # MODEL 4
        # ----------------------------------------------------

        predictions["Bass"] = (
            bass_forecast(
                train,
                horizon
            )
        )


        # ----------------------------------------------------
        # MODEL 5
        # ----------------------------------------------------

        predictions[
            "Analog + Bass Static"
        ] = (
            analog_bass_static(
                drug_id,
                train,
                train_end,
                horizon
            )
        )


        # ----------------------------------------------------
        # MODEL 6
        # ----------------------------------------------------

        predictions[
            "Analog + Bass Adaptive"
        ] = (
            adaptive_analog_bass(
                drug_id,
                train,
                train_end,
                horizon
            )
        )


        # ----------------------------------------------------
        # EVALUATE
        # ----------------------------------------------------

        for model_name, predicted in predictions.items():

            metric_values = calculate_metrics(
                actual,
                predicted,
                train
            )

            class_values = classification_metrics(
                actual,
                predicted,
                train
            )


            row = {
                "split_id": split_id,
                "drug_id": drug_id,
                "model": model_name,
                **metric_values,
                **class_values
            }

            results.append(
                row
            )


            for i in range(
                horizon
            ):

                prediction_records.append(
                    {
                        "split_id": split_id,
                        "drug_id": drug_id,
                        "model": model_name,
                        "month": (
                            validation_start
                            + i
                        ),
                        "actual": actual[i],
                        "predicted": predicted[i],
                        "error": (
                            actual[i]
                            -
                            predicted[i]
                        )
                    }
                )


results_df = pd.DataFrame(
    results
)

predictions_df = pd.DataFrame(
    prediction_records
)


# ============================================================
# 14. SAVE RAW BACKTEST RESULTS
# ============================================================

results_df.to_csv(
    OUTPUT_DIR /
    "rolling_backtest_results.csv",
    index=False
)

predictions_df.to_csv(
    OUTPUT_DIR /
    "rolling_predictions.csv",
    index=False
)


# ============================================================
# 15. MODEL-WISE SUMMARY
# ============================================================

print("\n" + "=" * 80)
print("MODEL-WISE BACKTEST PERFORMANCE")
print("=" * 80)


summary = (
    results_df
    .groupby("model")
    .agg(
        MAE_mean=("MAE", "mean"),
        MAE_std=("MAE", "std"),

        RMSE_mean=("RMSE", "mean"),
        RMSE_std=("RMSE", "std"),

        MAPE_mean=("MAPE", "mean"),
        MAPE_std=("MAPE", "std"),

        sMAPE_mean=("sMAPE", "mean"),
        sMAPE_std=("sMAPE", "std"),

        MASE_mean=("MASE", "mean"),
        MASE_std=("MASE", "std"),

        R2_mean=("R2", "mean"),
        R2_std=("R2", "std"),

        Accuracy_mean=("Accuracy", "mean"),
        Precision_mean=("Precision", "mean"),
        Recall_mean=("Recall", "mean"),
        F1_mean=("F1", "mean")
    )
    .reset_index()
)


summary = summary.sort_values(
    [
        "MASE_mean",
        "RMSE_mean",
        "sMAPE_mean"
    ],
    ascending=[
        True,
        True,
        True
    ]
)


print(
    summary.to_string(
        index=False
    )
)


summary.to_csv(
    OUTPUT_DIR /
    "model_comparison.csv",
    index=False
)


# ============================================================
# 16. BEST MODEL
# ============================================================

valid_summary = summary[
    summary["MASE_mean"].notna()
].copy()


if len(valid_summary) == 0:

    raise RuntimeError(
        "No valid model metrics available."
    )


best_model = (
    valid_summary.iloc[0]["model"]
)

best_mase = (
    valid_summary.iloc[0]["MASE_mean"]
)

best_rmse = (
    valid_summary.iloc[0]["RMSE_mean"]
)

best_smape = (
    valid_summary.iloc[0]["sMAPE_mean"]
)


print("\n" + "=" * 80)
print("MODEL RANKING")
print("=" * 80)


for rank, (_, row) in enumerate(
    valid_summary.iterrows(),
    start=1
):

    print(
        f"{rank}. "
        f"{row['model']} | "
        f"MASE={row['MASE_mean']:.4f} | "
        f"RMSE={row['RMSE_mean']:.2f} | "
        f"sMAPE={row['sMAPE_mean']:.2f}%"
    )


print(
    f"\nWINNER: {best_model}"
)

print(
    f"MASE : {best_mase:.4f}"
)

print(
    f"RMSE : {best_rmse:.2f}"
)

print(
    f"sMAPE: {best_smape:.2f}%"
)


# ============================================================
# 17. OVERFITTING / UNDERFITTING ANALYSIS
# ============================================================

print("\n" + "=" * 80)
print("GENERALIZATION ANALYSIS")
print("=" * 80)


for model_name in MODEL_NAMES:

    model_results = results_df[
        results_df["model"] == model_name
    ]

    if len(model_results) == 0:

        continue


    mean_mase = (
        model_results["MASE"]
        .mean()
    )

    mean_mae = (
        model_results["MAE"]
        .mean()
    )


    print(
        f"\n{model_name}"
    )

    print(
        f"  Mean validation MAE : "
        f"{mean_mae:.2f}"
    )

    print(
        f"  Mean validation MASE: "
        f"{mean_mase:.4f}"
    )


    if (
        pd.notna(mean_mase)
        and
        mean_mase < 1
    ):

        print(
            "  Conclusion: GOOD "
            "GENERALIZATION"
        )

        print(
            "  Reason: MASE < 1 means "
            "the model beats the naive "
            "one-step historical scale "
            "on average."
        )

    elif (
        pd.notna(mean_mase)
        and
        mean_mase >= 1
    ):

        print(
            "  Conclusion: POSSIBLE "
            "UNDERPERFORMANCE"
        )

        print(
            "  Reason: MASE >= 1 means "
            "the model does not consistently "
            "beat the naive benchmark."
        )

    else:

        print(
            "  Conclusion: INSUFFICIENT "
            "EVIDENCE"
        )


# ============================================================
# 18. SAVE WINNER
# ============================================================

winner_df = pd.DataFrame(
    [
        {
            "selected_model": best_model,
            "mean_MASE": best_mase,
            "mean_RMSE": best_rmse,
            "mean_sMAPE": best_smape
        }
    ]
)


winner_df.to_csv(
    OUTPUT_DIR /
    "selected_model.csv",
    index=False
)


# ============================================================
# 19. FINAL OUTPUT
# ============================================================

print("\n" + "=" * 80)
print("STEP 10 COMPLETE")
print("=" * 80)

print(
    f"[OK] Evaluated "
    f"{len(MODEL_NAMES)} models"
)

print(
    f"[OK] Historical drugs: "
    f"{len(drug_ids)}"
)

print(
    f"[OK] Rolling validation windows: "
    f"{len(splits)}"
)

print(
    f"[OK] Selected model: "
    f"{best_model}"
)

print("\nGenerated files:")

print(
    "[OK] models/rolling_backtest_results.csv"
)

print(
    "[OK] models/rolling_predictions.csv"
)

print(
    "[OK] models/model_comparison.csv"
)

print(
    "[OK] models/selected_model.csv"
)

print("\n" + "=" * 80)