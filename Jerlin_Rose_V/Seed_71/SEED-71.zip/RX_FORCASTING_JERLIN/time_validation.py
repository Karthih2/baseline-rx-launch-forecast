import pandas as pd
import numpy as np

from pathlib import Path


# ============================================================
# STEP 9 — TIME-AWARE VALIDATION SETUP
# ============================================================

DATA_DIR = Path("processed_data")
OUTPUT_DIR = Path("validation")

OUTPUT_DIR.mkdir(exist_ok=True)

ANALOG_RX_FILE = DATA_DIR / "analog_rx.csv"


print("=" * 70)
print("STEP 9 — TIME-AWARE VALIDATION SETUP")
print("=" * 70)


# ============================================================
# 1. LOAD ANALOG MONTHLY Rx DATA
# ============================================================

print("\nLoading analog monthly Rx data...")

analog_rx = pd.read_csv(
    ANALOG_RX_FILE
)

analog_rx = analog_rx.sort_values(
    ["drug_id", "month"]
).reset_index(drop=True)

print(
    f"[OK] Loaded {len(analog_rx)} Rx observations"
)

print(
    f"[OK] Number of analog drugs: "
    f"{analog_rx['drug_id'].nunique()}"
)


# ============================================================
# 2. VALIDATE EACH DRUG HAS 36 MONTHS
# ============================================================

print("\nValidating monthly histories...")

drug_month_counts = (
    analog_rx
    .groupby("drug_id")["month"]
    .count()
)

if not (drug_month_counts == 36).all():

    invalid_drugs = drug_month_counts[
        drug_month_counts != 36
    ]

    raise ValueError(
        f"Some drugs do not have exactly 36 months:\n"
        f"{invalid_drugs}"
    )

print(
    "[PASS] Every analog has exactly 36 months"
)


# ============================================================
# 3. DEFINE ROLLING-ORIGIN SPLITS
# ============================================================

print("\nCreating rolling-origin validation splits...")

splits = [
    {
        "split_id": "split_1",
        "train_start": 1,
        "train_end": 18,
        "validation_start": 19,
        "validation_end": 24,
    },
    {
        "split_id": "split_2",
        "train_start": 1,
        "train_end": 24,
        "validation_start": 25,
        "validation_end": 30,
    },
    {
        "split_id": "split_3",
        "train_start": 1,
        "train_end": 30,
        "validation_start": 31,
        "validation_end": 36,
    },
]


splits_df = pd.DataFrame(splits)


# ============================================================
# 4. DISPLAY SPLITS
# ============================================================

print("\n" + "=" * 70)
print("ROLLING-ORIGIN SPLITS")
print("=" * 70)

print(
    splits_df.to_string(index=False)
)


# ============================================================
# 5. CREATE TRAIN / VALIDATION RECORDS
# ============================================================

validation_records = []


for split in splits:

    split_id = split["split_id"]

    train_start = split["train_start"]
    train_end = split["train_end"]

    validation_start = split["validation_start"]
    validation_end = split["validation_end"]


    for drug_id in analog_rx["drug_id"].unique():

        drug_data = analog_rx[
            analog_rx["drug_id"] == drug_id
        ]


        train_data = drug_data[
            (drug_data["month"] >= train_start)
            &
            (drug_data["month"] <= train_end)
        ]


        validation_data = drug_data[
            (drug_data["month"] >= validation_start)
            &
            (drug_data["month"] <= validation_end)
        ]


        validation_records.append(
            {
                "split_id": split_id,

                "drug_id": drug_id,

                "train_start": train_start,

                "train_end": train_end,

                "validation_start":
                    validation_start,

                "validation_end":
                    validation_end,

                "train_observations":
                    len(train_data),

                "validation_observations":
                    len(validation_data),
            }
        )


validation_df = pd.DataFrame(
    validation_records
)


# ============================================================
# 6. VALIDATE SPLIT SIZES
# ============================================================

print("\n" + "=" * 70)
print("SPLIT VALIDATION")
print("=" * 70)


expected_train_sizes = {
    "split_1": 18,
    "split_2": 24,
    "split_3": 30,
}

expected_validation_sizes = {
    "split_1": 6,
    "split_2": 6,
    "split_3": 6,
}


for split_id in expected_train_sizes:

    current = validation_df[
        validation_df["split_id"] == split_id
    ]

    train_sizes = (
        current["train_observations"]
        .unique()
        .tolist()
    )

    validation_sizes = (
        current["validation_observations"]
        .unique()
        .tolist()
    )


    expected_train = (
        expected_train_sizes[split_id]
    )

    expected_validation = (
        expected_validation_sizes[split_id]
    )


    if train_sizes != [expected_train]:

        raise ValueError(
            f"{split_id}: unexpected train size "
            f"{train_sizes}"
        )


    if validation_sizes != [expected_validation]:

        raise ValueError(
            f"{split_id}: unexpected validation size "
            f"{validation_sizes}"
        )


    print(
        f"[PASS] {split_id}: "
        f"train={expected_train}, "
        f"validation={expected_validation}"
    )


# ============================================================
# 7. CHECK TEMPORAL ORDER
# ============================================================

print("\nChecking temporal ordering...")

for split in splits:

    if (
        split["train_end"]
        >= split["validation_start"]
    ):

        raise ValueError(
            f"Temporal leakage detected in "
            f"{split['split_id']}"
        )


print(
    "[PASS] No temporal overlap between "
    "training and validation periods"
)


# ============================================================
# 8. CHECK NO FUTURE DATA IN TRAINING
# ============================================================

for split in splits:

    train_end = split["train_end"]
    validation_start = split["validation_start"]

    if train_end >= validation_start:

        raise ValueError(
            "Training contains future observations."
        )


print(
    "[PASS] Training data always precedes "
    "validation data"
)


# ============================================================
# 9. SAVE VALIDATION SPLITS
# ============================================================

split_file = (
    OUTPUT_DIR /
    "rolling_origin_splits.csv"
)

splits_df.to_csv(
    split_file,
    index=False
)


record_file = (
    OUTPUT_DIR /
    "validation_records.csv"
)

validation_df.to_csv(
    record_file,
    index=False
)


# ============================================================
# 10. CREATE A VISUAL TIMELINE
# ============================================================

print("\nCreating validation timeline...")

import matplotlib.pyplot as plt


plt.figure(figsize=(12, 6))

for i, split in enumerate(splits):

    train_months = range(
        split["train_start"],
        split["train_end"] + 1
    )

    validation_months = range(
        split["validation_start"],
        split["validation_end"] + 1
    )


    plt.scatter(
        train_months,
        [i + 1] * len(train_months),
        marker="s",
        label="Training" if i == 0 else ""
    )


    plt.scatter(
        validation_months,
        [i + 1] * len(validation_months),
        marker="o",
        label="Validation" if i == 0 else ""
    )


plt.xlabel("Month Since Launch")

plt.ylabel("Validation Split")

plt.title(
    "Rolling-Origin Time-Aware Validation"
)

plt.yticks(
    [1, 2, 3],
    ["Split 1", "Split 2", "Split 3"]
)

plt.legend()

plt.grid(
    alpha=0.3
)

plt.tight_layout()

timeline_file = (
    OUTPUT_DIR /
    "validation_timeline.png"
)

plt.savefig(
    timeline_file,
    dpi=150
)

plt.close()


# ============================================================
# 11. FINAL SUMMARY
# ============================================================

print("\n" + "=" * 70)
print("STEP 9 COMPLETE")
print("=" * 70)

print(
    "Validation strategy: Rolling-Origin"
)

print(
    "Number of splits: 3"
)

print(
    "Validation horizon per split: 6 months"
)

print(
    "\nSplit 1: Train 1–18  → Validate 19–24"
)

print(
    "Split 2: Train 1–24  → Validate 25–30"
)

print(
    "Split 3: Train 1–30  → Validate 31–36"
)

print(
    f"\n[OK] {split_file}"
)

print(
    f"[OK] {record_file}"
)

print(
    f"[OK] {timeline_file}"
)

print("\n" + "=" * 70)