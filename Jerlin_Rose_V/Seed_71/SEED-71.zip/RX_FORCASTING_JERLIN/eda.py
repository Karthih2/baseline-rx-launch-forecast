import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from pathlib import Path


# ============================================================
# STEP 8 — EXPLORATORY DATA ANALYSIS
# ============================================================

DATA_DIR = Path("processed_data")
OUTPUT_DIR = Path("eda")

OUTPUT_DIR.mkdir(exist_ok=True)


ANALOG_STATIC_FILE = DATA_DIR / "analog_static.csv"
ANALOG_RX_FILE = DATA_DIR / "analog_rx.csv"
NEW_STATIC_FILE = DATA_DIR / "new_drug_static.csv"
NEW_RX_FILE = DATA_DIR / "new_drug_rx.csv"
NEW_MONTHLY_FILE = DATA_DIR / "new_drug_monthly_rx.csv"
TOP5_FILE = DATA_DIR / "top5_analogs.csv"


print("=" * 70)
print("STEP 8 — EXPLORATORY DATA ANALYSIS")
print("=" * 70)


# ============================================================
# 1. LOAD DATA
# ============================================================

print("\nLoading processed datasets...")

analog_static = pd.read_csv(
    ANALOG_STATIC_FILE
)

analog_rx = pd.read_csv(
    ANALOG_RX_FILE
)

new_static = pd.read_csv(
    NEW_STATIC_FILE
)

new_rx = pd.read_csv(
    NEW_RX_FILE
)

new_monthly = pd.read_csv(
    NEW_MONTHLY_FILE
)

top5 = pd.read_csv(
    TOP5_FILE
)

print(
    f"[OK] Analog static: {len(analog_static)} rows"
)

print(
    f"[OK] Analog Rx: {len(analog_rx)} rows"
)

print(
    f"[OK] New drug weekly Rx: {len(new_rx)} rows"
)

print(
    f"[OK] New drug monthly Rx: {len(new_monthly)} rows"
)

print(
    f"[OK] Top-5 analogs: {len(top5)}"
)


# ============================================================
# 2. BASIC DESCRIPTIVE STATISTICS
# ============================================================

print("\n" + "=" * 70)
print("1. BASIC Rx STATISTICS")
print("=" * 70)

print("\nAnalog Rx statistics:")

print(
    analog_rx["rx"].describe()
)


print("\nNew drug weekly Rx statistics:")

print(
    new_rx["rx"].describe()
)


print("\nNew drug monthly Rx statistics:")

print(
    new_monthly["monthly_rx"].describe()
)


# ============================================================
# 3. ANALOG Rx DISTRIBUTION
# ============================================================

print("\nCreating analog Rx distribution plot...")

plt.figure(figsize=(10, 6))

plt.hist(
    analog_rx["rx"],
    bins=30
)

plt.xlabel("Prescription Count (Rx)")
plt.ylabel("Frequency")
plt.title("Distribution of Analog Drug Rx")

plt.tight_layout()

plt.savefig(
    OUTPUT_DIR / "analog_rx_distribution.png",
    dpi=150
)

plt.close()


# ============================================================
# 4. NEW DRUG WEEKLY Rx DISTRIBUTION
# ============================================================

print("Creating new-drug Rx distribution plot...")

plt.figure(figsize=(10, 6))

plt.hist(
    new_rx["rx"],
    bins=10
)

plt.xlabel("Prescription Count (Rx)")
plt.ylabel("Frequency")
plt.title("Distribution of New Drug Weekly Rx")

plt.tight_layout()

plt.savefig(
    OUTPUT_DIR / "new_drug_rx_distribution.png",
    dpi=150
)

plt.close()


# ============================================================
# 5. ANALOG LAUNCH CURVES
# ============================================================

print("Creating analog launch curves...")

plt.figure(figsize=(12, 7))

for drug_id, group in analog_rx.groupby("drug_id"):

    group = group.sort_values("month")

    plt.plot(
        group["month"],
        group["rx"],
        alpha=0.35
    )


plt.xlabel("Month Since Launch")
plt.ylabel("Prescription Count (Rx)")
plt.title("Historical Rx Launch Curves — 35 Analog Drugs")

plt.tight_layout()

plt.savefig(
    OUTPUT_DIR / "analog_launch_curves.png",
    dpi=150
)

plt.close()


# ============================================================
# 6. TOP-5 ANALOG LAUNCH CURVES
# ============================================================

print("Creating top-5 analog launch curves...")

plt.figure(figsize=(12, 7))

for drug_id in top5["drug_id"]:

    group = analog_rx[
        analog_rx["drug_id"] == drug_id
    ].sort_values("month")

    drug_name = top5.loc[
        top5["drug_id"] == drug_id,
        "drug_name"
    ].iloc[0]

    plt.plot(
        group["month"],
        group["rx"],
        label=f"{drug_id} - {drug_name}"
    )


plt.xlabel("Month Since Launch")
plt.ylabel("Prescription Count (Rx)")
plt.title("Top-5 Analog Rx Launch Curves")

plt.legend()

plt.tight_layout()

plt.savefig(
    OUTPUT_DIR / "top5_analog_curves.png",
    dpi=150
)

plt.close()


# ============================================================
# 7. NEW DRUG WEEKLY Rx CURVE
# ============================================================

print("Creating new-drug weekly Rx curve...")

plt.figure(figsize=(10, 6))

plt.plot(
    new_rx["week"],
    new_rx["rx"],
    marker="o"
)

plt.xlabel("Week Since Launch")
plt.ylabel("Prescription Count (Rx)")
plt.title("New Drug Early Rx Curve")

plt.tight_layout()

plt.savefig(
    OUTPUT_DIR / "new_drug_weekly_curve.png",
    dpi=150
)

plt.close()


# ============================================================
# 8. NEW DRUG MONTHLY Rx CURVE
# ============================================================

print("Creating new-drug monthly Rx curve...")

plt.figure(figsize=(10, 6))

plt.plot(
    new_monthly["month"],
    new_monthly["monthly_rx"],
    marker="o"
)

plt.xlabel("Month Since Launch")
plt.ylabel("Monthly Prescription Count (Rx)")
plt.title("New Drug Monthly Rx Curve")

plt.tight_layout()

plt.savefig(
    OUTPUT_DIR / "new_drug_monthly_curve.png",
    dpi=150
)

plt.close()


# ============================================================
# 9. CATEGORICAL DISTRIBUTIONS
# ============================================================

categorical_columns = [
    "mechanism_of_action",
    "route_of_administration",
    "target_specialty",
    "launch_quarter",
]


for column in categorical_columns:

    print(
        f"Creating categorical plot: {column}"
    )

    counts = (
        analog_static[column]
        .value_counts()
        .sort_values(ascending=False)
    )

    plt.figure(figsize=(12, 7))

    counts.plot(
        kind="bar"
    )

    plt.xlabel(column)
    plt.ylabel("Number of Analog Drugs")

    plt.title(
        f"Distribution of {column}"
    )

    plt.xticks(
        rotation=45,
        ha="right"
    )

    plt.tight_layout()

    plt.savefig(
        OUTPUT_DIR /
        f"{column}_distribution.png",
        dpi=150
    )

    plt.close()


# ============================================================
# 10. NUMERICAL FEATURE DISTRIBUTIONS
# ============================================================

numerical_columns = [
    "market_size",
    "competitive_density",
    "payer_restrictiveness",
    "promotional_intensity",
    "price_tier",
]


for column in numerical_columns:

    print(
        f"Creating numerical plot: {column}"
    )

    plt.figure(figsize=(10, 6))

    plt.hist(
        analog_static[column],
        bins=10
    )

    plt.xlabel(column)
    plt.ylabel("Frequency")

    plt.title(
        f"Distribution of {column}"
    )

    plt.tight_layout()

    plt.savefig(
        OUTPUT_DIR /
        f"{column}_distribution.png",
        dpi=150
    )

    plt.close()


# ============================================================
# 11. CORRELATION ANALYSIS
# ============================================================

print("\nCreating numerical correlation matrix...")

correlation_columns = [
    "market_size",
    "competitive_density",
    "payer_restrictiveness",
    "promotional_intensity",
    "price_tier",
]

correlation_matrix = (
    analog_static[
        correlation_columns
    ]
    .corr()
)


print("\nCorrelation matrix:")

print(
    correlation_matrix
)


plt.figure(figsize=(9, 7))

plt.imshow(
    correlation_matrix,
    aspect="auto"
)

plt.colorbar(
    label="Correlation"
)

plt.xticks(
    range(len(correlation_columns)),
    correlation_columns,
    rotation=45,
    ha="right"
)

plt.yticks(
    range(len(correlation_columns)),
    correlation_columns
)

plt.title(
    "Correlation Matrix of Numerical Static Features"
)

plt.tight_layout()

plt.savefig(
    OUTPUT_DIR / "correlation_matrix.png",
    dpi=150
)

plt.close()


# ============================================================
# 12. MARKET SIZE VS Rx
# ============================================================

print("Creating market size vs Rx plot...")

drug_rx_summary = (
    analog_rx
    .groupby("drug_id")["rx"]
    .mean()
    .reset_index(name="mean_rx")
)

market_rx = analog_static[
    [
        "drug_id",
        "market_size"
    ]
].merge(
    drug_rx_summary,
    on="drug_id"
)


plt.figure(figsize=(10, 6))

plt.scatter(
    market_rx["market_size"],
    market_rx["mean_rx"]
)

plt.xlabel("Market Size")
plt.ylabel("Mean Rx")

plt.title(
    "Market Size vs Mean Rx"
)

plt.tight_layout()

plt.savefig(
    OUTPUT_DIR / "market_size_vs_mean_rx.png",
    dpi=150
)

plt.close()


# ============================================================
# 13. TOP-5 vs NEW DRUG EARLY CURVE
# ============================================================

print("Creating top-5 vs new-drug comparison...")

plt.figure(figsize=(12, 7))


for drug_id in top5["drug_id"]:

    group = analog_rx[
        analog_rx["drug_id"] == drug_id
    ].sort_values("month")

    plt.plot(
        group["month"],
        group["rx"],
        alpha=0.5
    )


plt.plot(
    new_monthly["month"],
    new_monthly["monthly_rx"],
    marker="o",
    linewidth=3,
    label="NEW_001"
)


plt.xlabel("Month Since Launch")

plt.ylabel(
    "Monthly Prescription Count (Rx)"
)

plt.title(
    "New Drug vs Top-5 Analog Launch Curves"
)

plt.legend()

plt.tight_layout()

plt.savefig(
    OUTPUT_DIR /
    "new_drug_vs_top5_analogs.png",
    dpi=150
)

plt.close()


# ============================================================
# 14. SAVE DESCRIPTIVE STATISTICS
# ============================================================

print("Saving descriptive statistics...")

analog_statistics = (
    analog_rx["rx"]
    .describe()
    .to_frame()
)

analog_statistics.to_csv(
    OUTPUT_DIR /
    "analog_rx_statistics.csv"
)


new_statistics = (
    new_rx["rx"]
    .describe()
    .to_frame()
)

new_statistics.to_csv(
    OUTPUT_DIR /
    "new_drug_rx_statistics.csv"
)


# ============================================================
# 15. FINAL SUMMARY
# ============================================================

print("\n" + "=" * 70)
print("EDA COMPLETE")
print("=" * 70)

print(
    f"EDA outputs saved to: {OUTPUT_DIR}"
)

print("\nGenerated visualizations include:")

print("[OK] Analog Rx distribution")
print("[OK] New-drug Rx distribution")
print("[OK] 35 analog launch curves")
print("[OK] Top-5 analog curves")
print("[OK] New-drug weekly curve")
print("[OK] New-drug monthly curve")
print("[OK] Categorical distributions")
print("[OK] Numerical distributions")
print("[OK] Correlation matrix")
print("[OK] Market size vs mean Rx")
print("[OK] New drug vs top-5 analogs")

print("\n" + "=" * 70)
print("STEP 8 COMPLETE")
print("=" * 70)