import pandas as pd
import numpy as np

from pathlib import Path
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics.pairwise import cosine_similarity


# ============================================================
# STEP 4 + STEP 5
# ANALOG SIMILARITY + TOP-5 ANALOG SELECTION
# ============================================================

INPUT_DIR = Path("processed_data")
OUTPUT_DIR = Path("processed_data")

ANALOG_FILE = INPUT_DIR / "analog_static.csv"
NEW_DRUG_FILE = INPUT_DIR / "new_drug_static.csv"

TOP_K = 5


print("=" * 70)
print("STEP 4 + 5 — ANALOG SIMILARITY & TOP-5 SELECTION")
print("=" * 70)


# ============================================================
# 1. LOAD PROCESSED DATA
# ============================================================

print("\nLoading processed data...")

analog_df = pd.read_csv(ANALOG_FILE)
new_drug_df = pd.read_csv(NEW_DRUG_FILE)

print(f"[OK] Analog drugs loaded: {len(analog_df)}")
print(f"[OK] New drug loaded: {len(new_drug_df)}")


# ============================================================
# 2. DEFINE STATIC FEATURES
# ============================================================

categorical_features = [
    "mechanism_of_action",
    "route_of_administration",
    "target_specialty",
    "launch_quarter",
]

numerical_features = [
    "market_size",
    "competitive_density",
    "payer_restrictiveness",
    "promotional_intensity",
    "special_designation",
    "price_tier",
]


# ============================================================
# 3. PREPARE FEATURES
# ============================================================

print("\nPreparing static features...")

X_analog_cat = analog_df[categorical_features]
X_new_cat = new_drug_df[categorical_features]

X_analog_num = analog_df[numerical_features].copy()
X_new_num = new_drug_df[numerical_features].copy()


# ============================================================
# 4. ENCODE CATEGORICAL FEATURES
# ============================================================

print("Encoding categorical features...")

encoder = OneHotEncoder(
    handle_unknown="ignore",
    sparse_output=False
)

combined_cat = pd.concat(
    [X_analog_cat, X_new_cat],
    axis=0,
    ignore_index=True
)

encoded_combined = encoder.fit_transform(combined_cat)

encoded_analog = encoded_combined[:len(analog_df)]
encoded_new = encoded_combined[len(analog_df):]


# ============================================================
# 5. SCALE NUMERICAL FEATURES
# ============================================================

print("Scaling numerical features...")

scaler = StandardScaler()

combined_num = pd.concat(
    [X_analog_num, X_new_num],
    axis=0,
    ignore_index=True
)

scaled_combined = scaler.fit_transform(combined_num)

scaled_analog_num = scaled_combined[:len(analog_df)]
scaled_new_num = scaled_combined[len(analog_df):]


# ============================================================
# 6. COMBINE FEATURES
# ============================================================

analog_features = np.hstack(
    [
        encoded_analog,
        scaled_analog_num
    ]
)

new_drug_features = np.hstack(
    [
        encoded_new,
        scaled_new_num
    ]
)


print(
    f"\nFinal feature vector size: "
    f"{analog_features.shape[1]}"
)


# ============================================================
# 7. CALCULATE COSINE SIMILARITY
# ============================================================

print("\nCalculating cosine similarity...")

similarities = cosine_similarity(
    new_drug_features,
    analog_features
)[0]


# ============================================================
# 8. ADD SIMILARITY SCORES
# ============================================================

results_df = analog_df[
    [
        "drug_id",
        "drug_name",
        "mechanism_of_action",
        "route_of_administration",
        "target_specialty",
    ]
].copy()

results_df["similarity_score"] = similarities


# ============================================================
# 9. RANK ALL 35 ANALOGS
# ============================================================

results_df = results_df.sort_values(
    "similarity_score",
    ascending=False
).reset_index(drop=True)

results_df["rank"] = np.arange(
    1,
    len(results_df) + 1
)


# ============================================================
# 10. SELECT TOP 5
# ============================================================

top5_df = results_df.head(TOP_K).copy()


# ============================================================
# 11. DISPLAY ALL ANALOG RANKINGS
# ============================================================

print("\n" + "=" * 70)
print("ALL 35 ANALOGS — SIMILARITY RANKING")
print("=" * 70)

print(
    results_df[
        [
            "rank",
            "drug_id",
            "drug_name",
            "similarity_score"
        ]
    ].to_string(index=False)
)


# ============================================================
# 12. DISPLAY TOP 5
# ============================================================

print("\n" + "=" * 70)
print("🏆 TOP 5 ANALOG DRUGS")
print("=" * 70)

print(
    top5_df[
        [
            "rank",
            "drug_id",
            "drug_name",
            "similarity_score"
        ]
    ].to_string(index=False)
)


# ============================================================
# 13. SAVE ALL SIMILARITY RESULTS
# ============================================================

all_results_file = (
    OUTPUT_DIR / "analog_similarity_scores.csv"
)

results_df.to_csv(
    all_results_file,
    index=False
)


# ============================================================
# 14. SAVE TOP 5
# ============================================================

top5_file = (
    OUTPUT_DIR / "top5_analogs.csv"
)

top5_df.to_csv(
    top5_file,
    index=False
)


# ============================================================
# 15. FINAL SUMMARY
# ============================================================

print("\n" + "=" * 70)
print("ANALOG SELECTION COMPLETE")
print("=" * 70)

print(f"Total analogs evaluated : {len(results_df)}")
print(f"Top analogs selected    : {len(top5_df)}")

print("\nGenerated files:")

print(
    f"[OK] {all_results_file}"
)

print(
    f"[OK] {top5_file}"
)

print("\n" + "=" * 70)
print("STEP 4 + STEP 5 COMPLETE")
print("=" * 70)