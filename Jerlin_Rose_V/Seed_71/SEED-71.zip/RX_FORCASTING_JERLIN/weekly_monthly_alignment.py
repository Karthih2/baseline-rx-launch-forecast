import pandas as pd
import numpy as np
from pathlib import Path


# ============================================================
# STEP 7 — WEEKLY → MONTHLY Rx ALIGNMENT
# ============================================================

DATA_DIR = Path("processed_data")

INPUT_FILE = DATA_DIR / "new_drug_rx.csv"

OUTPUT_FILE = DATA_DIR / "new_drug_monthly_rx.csv"

COMPARISON_FILE = DATA_DIR / "rx_alignment_summary.csv"


print("=" * 70)
print("STEP 7 — WEEKLY → MONTHLY Rx ALIGNMENT")
print("=" * 70)


# ============================================================
# 1. LOAD WEEKLY DATA
# ============================================================

print("\nLoading weekly new-drug Rx data...")

weekly_df = pd.read_csv(INPUT_FILE)

weekly_df = weekly_df.sort_values(
    "week"
).reset_index(drop=True)

print(
    f"[OK] Weekly observations loaded: "
    f"{len(weekly_df)}"
)

print(
    f"[OK] Week range: "
    f"{weekly_df['week'].min()} → "
    f"{weekly_df['week'].max()}"
)


# ============================================================
# 2. VALIDATE WEEKLY DATA
# ============================================================

expected_weeks = list(
    range(
        1,
        len(weekly_df) + 1
    )
)

actual_weeks = weekly_df["week"].tolist()

if actual_weeks != expected_weeks:

    raise ValueError(
        "Weekly observations are not continuous "
        "from Week 1 onward."
    )

if weekly_df["rx"].isna().any():

    raise ValueError(
        "Missing Rx values found."
    )

if (weekly_df["rx"] < 0).any():

    raise ValueError(
        "Negative Rx values found."
    )

print("[PASS] Weeks are continuous")
print("[PASS] No missing Rx values")
print("[PASS] No negative Rx values")


# ============================================================
# 3. ASSIGN 4-WEEK MONTH BUCKETS
# ============================================================

print("\nAssigning weekly observations to monthly buckets...")

# Week 1-4  -> Month 1
# Week 5-8  -> Month 2
# Week 9-12 -> Month 3
# Week 13-16 -> Month 4
# Week 17-20 -> Month 5
# Week 21-22 -> Month 6 (partial)

weekly_df["month"] = (
    ((weekly_df["week"] - 1) // 4) + 1
)


# ============================================================
# 4. IDENTIFY PARTIAL MONTH
# ============================================================

weeks_per_month = (
    weekly_df
    .groupby("month")["week"]
    .count()
    .reset_index(name="weeks_observed")
)

weeks_per_month["is_partial_month"] = (
    weeks_per_month["weeks_observed"] < 4
)


# ============================================================
# 5. AGGREGATE WEEKLY Rx INTO MONTHLY Rx
# ============================================================

monthly_df = (
    weekly_df
    .groupby(
        [
            "drug_id",
            "month"
        ],
        as_index=False
    )
    .agg(
        monthly_rx=("rx", "sum"),
        weeks_observed=("week", "count"),
        first_week=("week", "min"),
        last_week=("week", "max")
    )
)


# ============================================================
# 6. MARK PARTIAL MONTHS
# ============================================================

monthly_df["is_partial_month"] = (
    monthly_df["weeks_observed"] < 4
)


# ============================================================
# 7. OPTIONAL NORMALIZED MONTHLY RATE
# ============================================================

# For complete 4-week buckets:
# normalized value = actual monthly Rx
#
# For the final partial month:
# estimate what the Rx count would be
# if four weeks had been observed.
#
# IMPORTANT:
# We keep BOTH values.
# We do not replace actual observations.

monthly_df["monthly_rx_4week_equivalent"] = (
    monthly_df["monthly_rx"]
    / monthly_df["weeks_observed"]
    * 4
)


# ============================================================
# 8. DISPLAY ALIGNMENT
# ============================================================

print("\n" + "=" * 70)
print("WEEKLY → MONTHLY ALIGNMENT")
print("=" * 70)

print(
    monthly_df[
        [
            "month",
            "first_week",
            "last_week",
            "weeks_observed",
            "monthly_rx",
            "is_partial_month",
            "monthly_rx_4week_equivalent"
        ]
    ].to_string(index=False)
)


# ============================================================
# 9. VALIDATION
# ============================================================

print("\n" + "=" * 70)
print("ALIGNMENT VALIDATION")
print("=" * 70)

total_weekly_rx = weekly_df["rx"].sum()

total_monthly_rx = monthly_df["monthly_rx"].sum()

print(
    f"Total weekly Rx : {total_weekly_rx:,.2f}"
)

print(
    f"Total monthly Rx: {total_monthly_rx:,.2f}"
)

if np.isclose(
    total_weekly_rx,
    total_monthly_rx
):

    print(
        "[PASS] Monthly aggregation preserves "
        "total observed Rx"
    )

else:

    raise ValueError(
        "Monthly aggregation changed total Rx."
    )


# ============================================================
# 10. CHECK PARTIAL MONTH
# ============================================================

partial_months = monthly_df[
    monthly_df["is_partial_month"]
]

if len(partial_months) > 0:

    print(
        f"[INFO] Partial month(s): "
        f"{partial_months['month'].tolist()}"
    )

else:

    print(
        "[INFO] No partial month found."
    )


# ============================================================
# 11. SAVE MONTHLY DATA
# ============================================================

monthly_df.to_csv(
    OUTPUT_FILE,
    index=False
)


# ============================================================
# 12. CREATE SIMPLE ALIGNMENT SUMMARY
# ============================================================

summary_df = monthly_df[
    [
        "month",
        "first_week",
        "last_week",
        "weeks_observed",
        "monthly_rx",
        "is_partial_month",
        "monthly_rx_4week_equivalent"
    ]
].copy()


summary_df.to_csv(
    COMPARISON_FILE,
    index=False
)


# ============================================================
# 13. FINAL SUMMARY
# ============================================================

print("\n" + "=" * 70)
print("STEP 7 COMPLETE")
print("=" * 70)

print(
    f"Weekly observations : {len(weekly_df)}"
)

print(
    f"Monthly observations: {len(monthly_df)}"
)

print(
    f"Partial month(s)    : "
    f"{len(partial_months)}"
)

print(
    f"\n[OK] {OUTPUT_FILE}"
)

print(
    f"[OK] {COMPARISON_FILE}"
)

print("\n" + "=" * 70)