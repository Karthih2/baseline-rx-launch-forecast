import json
from pathlib import Path
from collections import Counter


# ============================================================
# STEP 2: DATA INGESTION & VALIDATION
# ============================================================

DATA_DIR = Path("data_seed71")

ANALOG_FILE = DATA_DIR / "analog_drugs.json"
NEW_DRUG_FILE = DATA_DIR / "new_drug.json"
SCENARIO_FILE = DATA_DIR / "scenario_assumptions.json"


# ------------------------------------------------------------
# 1. LOAD JSON FILES
# ------------------------------------------------------------

def load_json(path):
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


print("=" * 70)
print("STEP 2 — DATA INGESTION & VALIDATION")
print("=" * 70)

print("\nLoading datasets...")

analog_data = load_json(ANALOG_FILE)
new_drug_data = load_json(NEW_DRUG_FILE)
scenario_data = load_json(SCENARIO_FILE)

print(f"[OK] {ANALOG_FILE}")
print(f"[OK] {NEW_DRUG_FILE}")
print(f"[OK] {SCENARIO_FILE}")


# ------------------------------------------------------------
# 2. BASIC DATASET DIMENSIONS
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("1. DATASET DIMENSIONS")
print("=" * 70)

print(f"Analog drugs      : {len(analog_data)}")
print(f"New products      : {1 if isinstance(new_drug_data, dict) else len(new_drug_data)}")
print(f"Scenario records  : {len(scenario_data)}")


# ------------------------------------------------------------
# 3. EXPECTED COUNTS
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("2. EXPECTED COUNTS")
print("=" * 70)

checks = []

check = len(analog_data) == 35
checks.append(("35 historical analog drugs", check))
print(f"[{'PASS' if check else 'FAIL'}] 35 historical analog drugs")

check = isinstance(new_drug_data, dict)
checks.append(("1 new drug object", check))
print(f"[{'PASS' if check else 'FAIL'}] 1 new drug object")

check = len(scenario_data) == 3
checks.append(("3 scenario records", check))
print(f"[{'PASS' if check else 'FAIL'}] 3 scenario records")


# ------------------------------------------------------------
# 4. DISPLAY AVAILABLE KEYS
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("3. AVAILABLE KEYS")
print("=" * 70)

print("\nAnalog drug keys:")

if analog_data:
    for key in analog_data[0].keys():
        print(f"  - {key}")

print("\nNew drug keys:")

for key in new_drug_data.keys():
    print(f"  - {key}")

print("\nScenario keys:")

if scenario_data:
    for key in scenario_data[0].keys():
        print(f"  - {key}")


# ------------------------------------------------------------
# 5. DATA TYPES
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("4. DATA TYPES")
print("=" * 70)

print("\nAnalog drug data types:")

if analog_data:
    first_drug = analog_data[0]

    for key, value in first_drug.items():
        if key != "rx_curve":
            print(f"  {key:<30} {type(value).__name__}")

    print("\n  rx_curve:")
    if first_drug["rx_curve"]:
        for key, value in first_drug["rx_curve"][0].items():
            print(f"    {key:<28} {type(value).__name__}")


print("\nNew drug data types:")

for key, value in new_drug_data.items():
    if key != "early_rx":
        print(f"  {key:<30} {type(value).__name__}")

print("\n  early_rx:")
if new_drug_data["early_rx"]:
    for key, value in new_drug_data["early_rx"][0].items():
        print(f"    {key:<28} {type(value).__name__}")


# ------------------------------------------------------------
# 6. MISSING VALUES
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("5. MISSING VALUES")
print("=" * 70)

def find_missing(record):
    missing = []

    for key, value in record.items():
        if value is None or value == "":
            missing.append(key)

    return missing


analog_missing_count = 0

for drug in analog_data:
    missing = find_missing(drug)

    if missing:
        analog_missing_count += 1
        print(f"Analog {drug.get('drug_id')} missing: {missing}")

print(f"\nAnalog records with missing values: {analog_missing_count}")

new_missing = find_missing(new_drug_data)

print(f"New drug missing values: {new_missing if new_missing else 'None'}")

scenario_missing = 0

for scenario in scenario_data:
    missing = find_missing(scenario)

    if missing:
        scenario_missing += 1
        print(
            f"Scenario {scenario.get('scenario_id')} missing: {missing}"
        )

print(f"Scenario records with missing values: {scenario_missing}")


# ------------------------------------------------------------
# 7. DUPLICATE DRUG IDs
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("6. DUPLICATE IDs")
print("=" * 70)

analog_ids = [drug.get("drug_id") for drug in analog_data]

id_counts = Counter(analog_ids)

duplicate_ids = {
    drug_id: count
    for drug_id, count in id_counts.items()
    if count > 1
}

if duplicate_ids:
    print("Duplicate analog IDs:")
    for drug_id, count in duplicate_ids.items():
        print(f"  {drug_id}: {count} occurrences")
else:
    print("[PASS] No duplicate analog drug IDs")


# ------------------------------------------------------------
# 8. UNIQUE IDs
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("7. UNIQUE IDs")
print("=" * 70)

print(f"Unique analog IDs: {len(set(analog_ids))}")

if new_drug_data.get("drug_id"):
    print(f"New drug ID: {new_drug_data['drug_id']}")


# ------------------------------------------------------------
# 9. ANALOG RX OBSERVATION COUNTS
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("8. RX OBSERVATION COUNTS")
print("=" * 70)

rx_counts = []

for drug in analog_data:
    count = len(drug.get("rx_curve", []))
    rx_counts.append(count)

    print(
        f"{drug.get('drug_id'):<10} "
        f"Rx observations: {count}"
    )

print(f"\nMinimum analog Rx observations: {min(rx_counts)}")
print(f"Maximum analog Rx observations: {max(rx_counts)}")

check = all(count == 36 for count in rx_counts)

checks.append(("Every analog has 36 monthly Rx observations", check))

print(
    f"[{'PASS' if check else 'FAIL'}] "
    "Every analog has 36 monthly Rx observations"
)


# ------------------------------------------------------------
# 10. NEW DRUG WEEKLY OBSERVATIONS
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("9. NEW DRUG EARLY Rx")
print("=" * 70)

early_rx = new_drug_data.get("early_rx", [])

print(f"New drug ID: {new_drug_data.get('drug_id')}")
print(f"Weekly observations: {len(early_rx)}")

check = 18 <= len(early_rx) <= 26

checks.append(("New drug has 18–26 weekly observations", check))

print(
    f"[{'PASS' if check else 'FAIL'}] "
    "New drug has 18–26 weekly observations"
)


# ------------------------------------------------------------
# 11. CHRONOLOGICAL ORDER
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("10. CHRONOLOGICAL ORDER")
print("=" * 70)

analog_order_check = True

for drug in analog_data:
    months = [
        point.get("month")
        for point in drug.get("rx_curve", [])
    ]

    expected_months = list(range(1, 37))

    if months != expected_months:
        analog_order_check = False

        print(
            f"[FAIL] {drug.get('drug_id')} "
            f"months are not exactly 1–36"
        )

if analog_order_check:
    print("[PASS] All analog Rx curves are ordered Month 1 → Month 36")


weeks = [
    point.get("week")
    for point in early_rx
]

expected_weeks = list(range(1, len(early_rx) + 1))

if weeks == expected_weeks:
    print("[PASS] New drug weekly Rx is chronologically ordered")
else:
    print("[FAIL] New drug weekly Rx is not correctly ordered")


# ------------------------------------------------------------
# 12. INVALID RX VALUES
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("11. INVALID Rx VALUES")
print("=" * 70)

invalid_rx = []

for drug in analog_data:

    for point in drug.get("rx_curve", []):

        rx = point.get("rx")

        if not isinstance(rx, (int, float)):
            invalid_rx.append(
                (drug.get("drug_id"), point.get("month"), rx)
            )

        elif rx < 0:
            invalid_rx.append(
                (drug.get("drug_id"), point.get("month"), rx)
            )


for point in early_rx:

    rx = point.get("rx")

    if not isinstance(rx, (int, float)):
        invalid_rx.append(
            (new_drug_data.get("drug_id"), point.get("week"), rx)
        )

    elif rx < 0:
        invalid_rx.append(
            (new_drug_data.get("drug_id"), point.get("week"), rx)
        )


if invalid_rx:
    print("Invalid Rx values found:")

    for item in invalid_rx[:20]:
        print(item)

else:
    print("[PASS] No negative or non-numeric Rx values")


# ------------------------------------------------------------
# 13. NUMERICAL RANGES
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("12. NUMERICAL RANGES")
print("=" * 70)

market_sizes = [
    drug["market_size"]
    for drug in analog_data
]

competitive_density = [
    drug["competitive_density"]
    for drug in analog_data
]

payer_restrictiveness = [
    drug["payer_restrictiveness"]
    for drug in analog_data
]

promotional_intensity = [
    drug["promotional_intensity"]
    for drug in analog_data
]

price_tier = [
    drug["price_tier"]
    for drug in analog_data
]


def print_range(name, values):
    print(
        f"{name:<30} "
        f"min={min(values):,.2f} "
        f"max={max(values):,.2f}"
    )


print_range("Market size", market_sizes)
print_range("Competitive density", competitive_density)
print_range("Payer restrictiveness", payer_restrictiveness)
print_range("Promotional intensity", promotional_intensity)
print_range("Price tier", price_tier)


# ------------------------------------------------------------
# 14. CATEGORICAL DISTRIBUTIONS
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("13. CATEGORICAL DISTRIBUTIONS")
print("=" * 70)


def print_distribution(name, values):

    print(f"\n{name}")

    counts = Counter(values)

    for value, count in counts.items():
        print(f"  {value}: {count}")


print_distribution(
    "Mechanism of Action",
    [d["mechanism_of_action"] for d in analog_data]
)

print_distribution(
    "Route of Administration",
    [d["route_of_administration"] for d in analog_data]
)

print_distribution(
    "Target Specialty",
    [d["target_specialty"] for d in analog_data]
)

print_distribution(
    "Launch Quarter",
    [d["launch_quarter"] for d in analog_data]
)

print_distribution(
    "Special Designation",
    [d["special_designation"] for d in analog_data]
)


# ------------------------------------------------------------
# 15. FINAL VALIDATION SUMMARY
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("FINAL VALIDATION SUMMARY")
print("=" * 70)

passed = sum(check for _, check in checks)
total = len(checks)

print(f"Checks passed: {passed}/{total}")

if passed == total and not invalid_rx and not duplicate_ids:
    print("\n🎉 DATA INGESTION & VALIDATION PASSED")
    print("The Seed-71 datasets are ready for the next stage.")
else:
    print("\n⚠️ DATA VALIDATION NEEDS ATTENTION")
    print("Review the failed checks above before preprocessing.")